<?php

namespace Container5XxgJrB;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder519fb = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer072b1 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesc1fef = [
        
    ];

    public function getConnection()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'getConnection', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'getMetadataFactory', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'getExpressionBuilder', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'beginTransaction', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'getCache', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->getCache();
    }

    public function transactional($func)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'transactional', array('func' => $func), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->transactional($func);
    }

    public function commit()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'commit', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->commit();
    }

    public function rollback()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'rollback', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'getClassMetadata', array('className' => $className), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'createQuery', array('dql' => $dql), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'createNamedQuery', array('name' => $name), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'createQueryBuilder', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'flush', array('entity' => $entity), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'clear', array('entityName' => $entityName), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->clear($entityName);
    }

    public function close()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'close', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->close();
    }

    public function persist($entity)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'persist', array('entity' => $entity), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'remove', array('entity' => $entity), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'refresh', array('entity' => $entity), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'detach', array('entity' => $entity), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'merge', array('entity' => $entity), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'getRepository', array('entityName' => $entityName), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'contains', array('entity' => $entity), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'getEventManager', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'getConfiguration', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'isOpen', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'getUnitOfWork', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'getProxyFactory', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'initializeObject', array('obj' => $obj), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'getFilters', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'isFiltersStateClean', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'hasFilters', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return $this->valueHolder519fb->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer072b1 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder519fb) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder519fb = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder519fb->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, '__get', ['name' => $name], $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        if (isset(self::$publicPropertiesc1fef[$name])) {
            return $this->valueHolder519fb->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder519fb;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder519fb;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder519fb;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder519fb;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, '__isset', array('name' => $name), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder519fb;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder519fb;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, '__unset', array('name' => $name), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder519fb;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder519fb;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, '__clone', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        $this->valueHolder519fb = clone $this->valueHolder519fb;
    }

    public function __sleep()
    {
        $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, '__sleep', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;

        return array('valueHolder519fb');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer072b1 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer072b1;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer072b1 && ($this->initializer072b1->__invoke($valueHolder519fb, $this, 'initializeProxy', array(), $this->initializer072b1) || 1) && $this->valueHolder519fb = $valueHolder519fb;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder519fb;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder519fb;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
